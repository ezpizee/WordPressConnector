<?php
# Silence is golden.
defined('EZPIZEE_WP_VERSION') or die('Silent is gold');