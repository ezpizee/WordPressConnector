=== Ezpizee Connectorn ===
Contributors: Sothea Nim, Khon Pang, Channa Kao, Botin Pov, Rady Ren, Sopheap Horm, Sotheareach Sambath
Tags: saas, e-commerce
Requires at least: 4.6
Tested up to: 5.6
Stable tag: 0.0.3
License: GPLv2 or later

== Description ==

Ezpizee is a SaaS-based e-commerce platform. It is developed for SMEs. The product comes with Point Of Sales app (tablet and desktop), Inventory app, and web admin for managing commerce.

Ezpizee Connector the WordPress plugin used for WordPress user to manage their commerce experience right inside WordPress.

Major features in Ezpizee Connector include:

* Installing Ezpizee App in WordPress in a plug-and-play fashion.
* Enables Ezpizee's users to use WordPress as their tool to deliver their marketing experience.
* Enables Ezpizee's users to login and manage their e-commerce properties (i.e. Stores/Catalogs, PIM, Shopping Cart, Order, Discounts, ect) right inside WordPress.
* Enables WordPress's users with commerce capability.

== Installation ==

Upload the Ezpizee Connector plugin to your WordPress installation, activate it, and then enter your API credentials.

1, 2, 3: You're done!

== Changelog ==

= 0.0.3 =
*Release Date - 5 January 2021*